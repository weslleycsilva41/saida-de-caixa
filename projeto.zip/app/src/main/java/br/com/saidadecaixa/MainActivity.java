package br.com.saidadecaixa;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {

    private static final int ESCOLHER_ARQUIVO = 41;
    private WebView web;
    private ValueCallback<Uri[]> retornoArquivo;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setTextZoom(100);

        web.addJavascriptInterface(new Ponte(), "AndroidApp");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // nada para abrir o link
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (retornoArquivo != null) retornoArquivo.onReceiveValue(null);
                retornoArquivo = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Escolher a cópia de segurança"), ESCOLHER_ARQUIVO);
                } catch (Exception e) {
                    retornoArquivo = null;
                    return false;
                }
                return true;
            }
        });

        if (estado != null) {
            web.restoreState(estado);
        } else {
            web.loadUrl("file:///android_asset/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle saida) {
        super.onSaveInstanceState(saida);
        web.saveState(saida);
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent dados) {
        if (pedido == ESCOLHER_ARQUIVO && retornoArquivo != null) {
            Uri[] r = null;
            if (resultado == RESULT_OK && dados != null && dados.getData() != null) {
                r = new Uri[]{dados.getData()};
            }
            retornoArquivo.onReceiveValue(r);
            retornoArquivo = null;
            return;
        }
        super.onActivityResult(pedido, resultado, dados);
    }

    /** O tablet mudou entre claro e escuro: avisa a página (ela decide se segue ou não). */
    @Override
    public void onConfigurationChanged(Configuration nova) {
        super.onConfigurationChanged(nova);
        if (web != null) web.evaluateJavascript("window.__temaSistema && window.__temaSistema()", null);
    }

    /** Pinta as barras do Android (relógio em cima, botões embaixo) de acordo com o tema da página. */
    private void aplicarBarras(boolean escuro) {
        Window w = getWindow();
        int cor = escuro ? 0xFF000000 : 0xFFF2F2F7;
        w.setStatusBarColor(cor);
        w.setNavigationBarColor(cor);
        if (web != null) web.setBackgroundColor(cor);
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                int claras = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS;
                c.setSystemBarsAppearance(escuro ? 0 : claras, claras);
            }
        } else {
            View d = w.getDecorView();
            int claras = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            int f = d.getSystemUiVisibility();
            d.setSystemUiVisibility(escuro ? (f & ~claras) : (f | claras));
        }
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.__voltar && window.__voltar()) ? 'sim' : 'nao'", valor -> {
            if (valor == null || !valor.contains("sim")) finish();
        });
    }

    /** Ponte usada pela página para salvar arquivos (planilha e cópia de segurança). */
    private class Ponte {
        @JavascriptInterface
        public boolean sistemaEscuro() {
            int modo = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            return modo == Configuration.UI_MODE_NIGHT_YES;
        }

        @JavascriptInterface
        public void setTema(final boolean escuro) {
            runOnUiThread(() -> aplicarBarras(escuro));
        }

        @JavascriptInterface
        public String saveFile(String nome, String base64, String tipo, boolean compartilhar) {
            try {
                byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, nome);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, tipo);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    final Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) return "erro";
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        if (os == null) return "erro";
                        os.write(bytes);
                    }
                    if (compartilhar) compartilhar(uri, tipo);
                    return "ok";
                } else {
                    File pasta = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (pasta == null) pasta = getFilesDir();
                    File f = new File(pasta, nome);
                    try (FileOutputStream fo = new FileOutputStream(f)) {
                        fo.write(bytes);
                    }
                    return "app:" + f.getAbsolutePath();
                }
            } catch (Exception e) {
                return "erro";
            }
        }
    }

    private void compartilhar(final Uri uri, final String tipo) {
        runOnUiThread(() -> {
            try {
                Intent enviar = new Intent(Intent.ACTION_SEND);
                enviar.setType(tipo);
                enviar.putExtra(Intent.EXTRA_STREAM, uri);
                enviar.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(enviar, "Mandar uma cópia para..."));
            } catch (Exception e) {
                // o arquivo já ficou salvo na pasta Download
            }
        });
    }
}
